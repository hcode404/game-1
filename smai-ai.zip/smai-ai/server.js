import http from 'node:http';
import {createHmac,randomBytes,timingSafeEqual} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {dirname,resolve} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';

const root=dirname(fileURLToPath(import.meta.url));
function cookies(req){return Object.fromEntries((req.headers.cookie||'').split(';').filter(s=>s.includes('=')).map(s=>{const index=s.indexOf('=');return [s.slice(0,index).trim(),s.slice(index+1).trim()]}));}
export function sign(payload,secret){const content=Buffer.from(JSON.stringify(payload)).toString('base64url');return content+'.'+createHmac('sha256',secret).update(content).digest('base64url')}
export function unsign(value,secret){try{const [content,signature,...extra]=value.split('.');if(extra.length)return null;const expected=createHmac('sha256',secret).update(content).digest();const actual=Buffer.from(signature,'base64url');if(actual.length!==expected.length||!timingSafeEqual(actual,expected))return null;const payload=JSON.parse(Buffer.from(content,'base64url'));if(!Number.isFinite(payload.exp)||payload.exp<=Date.now())return null;return payload;}catch{return null}}
export function createApp({clientId,secret,origin,verifyGoogle,secure=true,browserURL='',browserToken='',browserOwnerSub='',browserOwnerEmail='',fetchBrowser=fetch,runnerURL='',runnerToken='',homeURL='',homeToken='',fetchTools=fetch,modelURL='',modelToken='',stateStore=null}){
  if(!secret||secret.length<32)throw Error('SESSION_SECRET must contain 32+ unpredictable characters');
  const publicOrigin=new URL(origin).origin;
  const staticFiles=new Map([['/','index.html'],['/app.js','app.js'],['/core.js','core.js'],['/model-worker.js','model-worker.js'],['/style.css','style.css']]);
  const cookieOptions='; HttpOnly; SameSite=Lax; Path=/'+(secure?'; Secure':'');
  const ownsBrowser=user=>!!(user&&(browserOwnerSub?user.id===browserOwnerSub:browserOwnerEmail&&user.email.toLowerCase()===browserOwnerEmail.toLowerCase()));
  const browserConnected=user=>!!(browserURL&&browserToken&&ownsBrowser(user));
  if(browserURL&&new URL(browserURL).protocol!=='https:')throw Error('Browser service must use HTTPS');
  const toolConnections=user=>({runnerConnected:!!(ownsBrowser(user)&&runnerURL&&runnerToken),homeConnected:!!(ownsBrowser(user)&&homeURL&&homeToken),modelConnected:!!(ownsBrowser(user)&&modelURL)});
  for(const endpoint of [runnerURL,homeURL,modelURL])if(endpoint&&new URL(endpoint).protocol!=='https:')throw Error('Integration endpoints require HTTPS');
  async function upstream(url,token,body,timeout=30000){const response=await fetchTools(url,{method:body?'POST':'GET',headers:{Authorization:'Bearer '+token,...(body?{'Content-Type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{}),redirect:'error',signal:AbortSignal.timeout(timeout)});if(!response.ok)throw Error('Connected service request failed');return response.json()}
  async function tools(user,body){
    if(!ownsBrowser(user))throw Error('Owner authentication required');
    const connections=toolConnections(user);
    if(body.tool==='run_code'){
      if(!connections.runnerConnected)throw Error('Code runner is not connected');
      if(!['python','javascript','shell'].includes(body.language)||typeof body.code!=='string'||body.code.length>12000)throw Error('Invalid code request');
      return upstream(runnerURL.replace(/\/$/,'')+'/run',runnerToken,{language:body.language,code:body.code});
    }
    if(!connections.homeConnected)throw Error('Home Assistant is not connected');
    const base=homeURL.replace(/\/$/,'')+'/api';
    if(body.tool==='smart_home_list'){const states=await upstream(base+'/states',homeToken);return states.filter(x=>/^light\.[a-z0-9_]+$/.test(x.entity_id)).map(x=>({entity:x.entity_id,name:x.attributes?.friendly_name||x.entity_id,state:x.state}))}
    if(body.tool==='smart_home_light'){
      if(!/^light\.[a-z0-9_]+$/.test(body.entity)||!['on','off'].includes(body.state))throw Error('Choose a valid light and on/off state');
      await upstream(base+'/services/light/turn_'+body.state,homeToken,{entity_id:body.entity});
      const state=await upstream(base+'/states/'+body.entity,homeToken);return {entity:state.entity_id,state:state.state,requested:body.state,confirmed:state.state===body.state};
    }
    throw Error('Unknown integration tool');
  }
  async function proxyBrowser(req,res,user,path,body){
    if(!user){res.writeHead(401,{'Content-Type':'application/json'});return res.end(JSON.stringify({error:'Authentication required'}));}
    if(!browserConnected(user)){res.writeHead(403,{'Content-Type':'application/json'});return res.end(JSON.stringify({error:'Cloud browser is not configured for this account'}));}
    if(!['/health','/snapshot','/navigate','/click','/fill','/type','/scroll','/whatsapp/prepare','/evaluate'].includes(path)){res.writeHead(404);return res.end();}
    const response=await fetchBrowser(browserURL.replace(/\/$/,'')+path,{method:req.method,headers:{Authorization:'Bearer '+browserToken,Origin:publicOrigin,...(body?{'Content-Type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(35000)});
    res.writeHead(response.status,{'Content-Type':'application/json; charset=utf-8'});res.end(await response.text());
  }
  return http.createServer(async(req,res)=>{
    res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');
    res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');
    res.setHeader('Cross-Origin-Opener-Policy','same-origin-allow-popups');
    res.setHeader('Content-Security-Policy',"frame-ancestors 'none'; base-uri 'self'; object-src 'none'");
    function reply(status,value){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(value))}
    const session=unsign(cookies(req).smai_session||'',secret);
    const user=session?.type==='session'?session.user:null;
    const url=new URL(req.url,publicOrigin);
    try{
      if(req.method==='GET'&&url.pathname==='/health')return reply(200,{ok:true});
      if(req.method==='GET'&&url.pathname==='/api/auth/config'){
        if(!clientId)return reply(200,{configured:false});
        const nonce=randomBytes(32).toString('base64url');
        res.setHeader('Set-Cookie','smai_nonce='+sign({type:'nonce',nonce,exp:Date.now()+300000},secret)+cookieOptions+'; Max-Age=300');
        return reply(200,{configured:true,clientId,nonce});
      }
      if(req.method==='GET'&&url.pathname==='/api/state'){if(!user)return reply(401,{error:'Authentication required'});return reply(200,{data:stateStore?.get(user.id)||null,persistent:!!stateStore});}
      if(req.method==='GET'&&url.pathname==='/api/me')return user?reply(200,{user,browserConnected:browserConnected(user),...toolConnections(user)}):reply(401,{error:'Authentication required'});
      if(req.method==='GET'&&url.pathname.startsWith('/api/browser/'))return await proxyBrowser(req,res,user,url.pathname.slice('/api/browser'.length));
      if(req.method==='POST'){
        if(req.headers.origin!==publicOrigin)return reply(403,{error:'Invalid request origin'});
        const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>(url.pathname==='/api/state'?1500000:100000))return reply(413,{error:'Request too large'});chunks.push(chunk)}
        const body=JSON.parse(Buffer.concat(chunks).toString()||'{}');
        if(url.pathname==='/api/state'){if(!user)return reply(401,{error:'Authentication required'});if(!stateStore)return reply(503,{error:'Cloud history persistence is not configured'});if(!body.data||typeof body.data!=='object'||Array.isArray(body.data))return reply(400,{error:'Invalid conversation state'});stateStore.set(user.id,body.data);return reply(200,{saved:true});}
        if(url.pathname==='/api/chat'){
          if(!toolConnections(user).modelConnected)return reply(403,{error:'Server model is not configured for this account'});
          if(!Array.isArray(body.messages)||body.messages.length>24||body.messages.some(m=>!['system','user','assistant'].includes(m.role)||typeof m.content!=='string'||m.content.length>20000))return reply(400,{error:'Invalid model request'});
          const prompt=body.messages.map(m=>'<|im_start|>'+m.role+'\n'+m.content+'<|im_end|>\n').join('')+'<|im_start|>assistant\n';
          const result=await upstream(modelURL.replace(/\/$/,'')+'/completion',modelToken,{prompt,n_predict:768,temperature:0.2,stream:false,cache_prompt:true},120000);
          if(typeof result.content!=='string')throw Error('Model did not return text');return reply(200,{text:result.content});
        }
        if(url.pathname==='/api/tools'){if(!user)return reply(401,{error:'Authentication required'});if(!ownsBrowser(user))return reply(403,{error:'Owner authentication required'});return reply(200,await tools(user,body));}
        if(url.pathname.startsWith('/api/browser/'))return await proxyBrowser(req,res,user,url.pathname.slice('/api/browser'.length),body);
        if(url.pathname==='/api/auth/google'){
          if(!clientId)return reply(503,{error:'Google sign-in is not configured'});
          const pending=unsign(cookies(req).smai_nonce||'',secret);
          if(pending?.type!=='nonce'||!body.nonce||pending.nonce!==body.nonce||typeof body.credential!=='string')return reply(403,{error:'Invalid or expired sign-in request'});
          const payload=await verifyGoogle(body.credential,clientId);
          if(payload.nonce!==pending.nonce||payload.email_verified!==true||!payload.sub||!payload.email)return reply(401,{error:'Google account verification failed'});
          const user={id:payload.sub,name:payload.name||'',email:payload.email};
          const session=sign({type:'session',user,exp:Date.now()+8*3600000},secret);
          res.setHeader('Set-Cookie',['smai_session='+session+cookieOptions+'; Max-Age=28800','smai_nonce='+cookieOptions+'; Max-Age=0']);
          return reply(200,{user,browserConnected:browserConnected(user),...toolConnections(user)});
        }
        if(url.pathname==='/api/auth/logout'){
          res.setHeader('Set-Cookie','smai_session='+cookieOptions+'; Max-Age=0');
          return reply(200,{ok:true});
        }
        return reply(404,{error:'Not found'});
      }
      if(req.method==='GET'&&staticFiles.has(url.pathname)){
        const file=staticFiles.get(url.pathname);
        const mime=file.endsWith('.html')?'text/html':file.endsWith('.css')?'text/css':'text/javascript';
        const content=await readFile(resolve(root,'dist',file));res.writeHead(200,{'Content-Type':mime+'; charset=utf-8'});res.end(content);return;
      }
      return reply(404,{error:'Not found'});
    }catch{return reply(400,{error:'Request could not be completed. Check authentication configuration.'})}
  });
}
export async function start(){
  const {OAuth2Client}=await import('google-auth-library');
  const googleClient=new OAuth2Client();
  const port=Number(process.env.PORT||3000);
  const production=process.env.NODE_ENV==='production';
  if(production&&!process.env.PUBLIC_ORIGIN)throw Error('Set PUBLIC_ORIGIN to the exact HTTPS website origin');
  const origin=process.env.PUBLIC_ORIGIN||'http://localhost:'+port;
  if(production&&new URL(origin).protocol!=='https:')throw Error('Production requires an HTTPS origin');
  let stateStore=null;
  if(process.env.DATA_DIR){const {createStateStore}=await import('./state-store.js');stateStore=await createStateStore(process.env.DATA_DIR)}
  const server=createApp({clientId:process.env.GOOGLE_CLIENT_ID||'',secret:process.env.SESSION_SECRET||'',origin,secure:production,browserURL:process.env.BROWSER_SERVICE_URL||'',browserToken:process.env.BROWSER_ACCESS_TOKEN||'',browserOwnerSub:process.env.BROWSER_OWNER_GOOGLE_SUB||'',browserOwnerEmail:process.env.BROWSER_OWNER_EMAIL||'',stateStore,modelURL:process.env.MODEL_SERVICE_URL||'',modelToken:process.env.MODEL_ACCESS_TOKEN||'',runnerURL:process.env.RUNNER_SERVICE_URL||'',runnerToken:process.env.RUNNER_ACCESS_TOKEN||'',homeURL:process.env.HOME_ASSISTANT_URL||'',homeToken:process.env.HOME_ASSISTANT_TOKEN||'',verifyGoogle:async(credential,audience)=>{
    const ticket=await googleClient.verifyIdToken({idToken:credential,audience});return ticket.getPayload();
  }});
  server.listen(port,'0.0.0.0',()=>console.log('SMAI AI is ready'));
  return server;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href)start().catch(()=>{console.error('SMAI AI could not start. Check PUBLIC_ORIGIN, SESSION_SECRET and dependencies.');process.exit(1)});
