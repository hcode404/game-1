import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer,publicIP,publicURL} from '../browser-service/server.js';
const token='test-private-token-that-is-long-enough-123';
async function fixture(t){
  let currentURL='https://example.com',navigated='',typed='';
  const page={url:()=>currentURL,title:async()=> 'Example',goto:async url=>{navigated=url;currentURL=url;},evaluate:async()=>true,keyboard:{insertText:async text=>{typed=text;}}};
  const server=createServer({token,origin:'https://my-site.example',getPage:async()=>page,urlCheck:async url=>url});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  t.after(()=>new Promise(resolve=>server.close(resolve)));
  const base='http://127.0.0.1:'+server.address().port;
  const request=(path,body,extra={})=>fetch(base+path,{method:body?'POST':'GET',headers:{Authorization:'Bearer '+token,Origin:'https://my-site.example','Content-Type':'application/json',...extra},...(body?{body:JSON.stringify(body)}:{})});
  return {request,navigated:()=>navigated,typed:()=>typed};
}
test('reserved IPv4 and IPv6 addresses are blocked',()=>{for(const ip of ['127.0.0.1','10.0.0.1','192.168.1.1','172.16.0.1','169.254.169.254','100.64.0.1','::1','fc00::1','::ffff:127.0.0.1'])assert(!publicIP(ip),ip);assert(publicIP('8.8.8.8'));});
test('public URL check blocks mixed public/private DNS answers',async()=>{await assert.rejects(publicURL('https://example.com',async()=>[{address:'8.8.8.8'},{address:'127.0.0.1'}]));await assert.rejects(publicURL('file:///etc/passwd'));});
test('service requires authentication',async t=>{const f=await fixture(t);assert.equal((await f.request('/health',null,{Authorization:'Bearer wrong'})).status,401)});
test('service denies another website origin',async t=>{const f=await fixture(t);assert.equal((await f.request('/health',null,{Origin:'https://attacker.example'})).status,403)});
test('WhatsApp action stages a draft without sending',async t=>{const f=await fixture(t);const response=await f.request('/whatsapp/prepare',{phone:'972501234567',message:'Please send an invitation'});assert.equal(response.status,200);const body=await response.json();assert.equal(body.sent,false);assert(f.navigated().startsWith('https://web.whatsapp.com/send?'));assert(f.navigated().includes('phone=972501234567'));assert.equal(f.typed(),'');});
test('secure input rejects stale page identity',async t=>{const f=await fixture(t);const response=await f.request('/type',{text:'123456',expectedUrl:'https://another.example'});assert.equal(response.status,400);assert.equal(f.typed(),'')});
test('secure input is not returned in response',async t=>{const f=await fixture(t);const response=await f.request('/type',{text:'private-test-code',expectedUrl:'https://example.com'});assert.equal(response.status,200);assert.equal(f.typed(),'private-test-code');assert(!(await response.text()).includes('private-test-code'))});
test('secure input cannot implicitly submit using newlines',async t=>{const f=await fixture(t);const response=await f.request('/type',{text:'value\n',expectedUrl:'https://example.com'});assert.equal(response.status,400);assert.equal(f.typed(),'')});
