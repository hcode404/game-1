import http from 'node:http';
import {spawn} from 'node:child_process';
import {randomUUID,timingSafeEqual} from 'node:crypto';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
export function buildCommand(language,name){
 const runtimes={python:['python:3.12-alpine','python','-I','-'],javascript:['node:24-alpine','node','-'],shell:['alpine:3.22','sh','-s']};
 if(!Object.hasOwn(runtimes,language))throw Error('Unsupported language');
 return ['run','--pull=never','--rm','-i','--name',name,'--network=none','--read-only','--user=65534:65534','--cap-drop=ALL','--security-opt=no-new-privileges','--pids-limit=64','--memory=256m','--memory-swap=256m','--cpus=1','--tmpfs=/tmp:rw,noexec,nosuid,size=64m','--workdir=/tmp',...runtimes[language]];
}
export function runCode(language,code){return new Promise((resolveResult,reject)=>{
 const name='smai-'+randomUUID();const args=buildCommand(language,name);const child=spawn('docker',args,{stdio:['pipe','pipe','pipe'],env:{PATH:process.env.PATH}});
 let stdout='',stderr='',length=0,limited=false,timedOut=false,finished=false;
 function cleanup(){const job=spawn('docker',['rm','-f',name],{stdio:'ignore',env:{PATH:process.env.PATH}});job.on('error',()=>{});const stop=setTimeout(()=>job.kill('SIGKILL'),5000);stop.unref();job.on('close',()=>clearTimeout(stop));}
 function stop(){child.kill('SIGKILL');cleanup()}
 const timer=setTimeout(()=>{timedOut=true;stop()},20000);
 function capture(kind,chunk){const remaining=Math.max(0,32768-length);const text=chunk.subarray(0,remaining).toString();if(kind==='out')stdout+=text;else stderr+=text;length+=chunk.length;if(length>32768&&!limited){limited=true;stop()}}
 child.stdout.on('data',c=>capture('out',c));child.stderr.on('data',c=>capture('err',c));child.stdin.on('error',()=>{});
 child.on('error',error=>{if(finished)return;finished=true;clearTimeout(timer);cleanup();reject(Error('Runner infrastructure is unavailable'))});
 child.on('close',(exitCode,signal)=>{if(finished)return;finished=true;clearTimeout(timer);cleanup();resolveResult({stdout,stderr,exitCode,signal,timedOut,outputTruncated:limited})});
 child.stdin.end(code);
})}
export function createRunner({token,execute=runCode}){
 if(!token||token.length<32)throw Error('Set a random RUNNER_ACCESS_TOKEN of at least 32 characters');
 let running=false;
 return http.createServer(async(req,res)=>{
  const reply=(status,value)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(value))};
  if(req.method==='GET'&&req.url==='/health')return reply(200,{ok:true});
  const actual=Buffer.from(req.headers.authorization||'');const expected=Buffer.from('Bearer '+token);
  if(actual.length!==expected.length||!timingSafeEqual(actual,expected))return reply(401,{error:'Unauthorized'});
  if(req.method!=='POST'||req.url!=='/run')return reply(404,{error:'Not found'});
  if(running)return reply(429,{error:'A code job is already running'});
  try{
   const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>20000)return reply(413,{error:'Code is too large'});chunks.push(chunk)}
   const body=JSON.parse(Buffer.concat(chunks).toString());if(typeof body.code!=='string'||body.code.length>12000)return reply(400,{error:'Invalid code'});buildCommand(body.language,'validation');
   if(running)return reply(429,{error:'A code job is already running'});running=true;
   try{return reply(200,await execute(body.language,body.code))}finally{running=false}
  }catch{return reply(400,{error:'Code job failed; check runner configuration'})}
 });
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href){createRunner({token:process.env.RUNNER_ACCESS_TOKEN}).listen(Number(process.env.PORT||4200),'127.0.0.1',()=>console.log('SMAI code runner ready on loopback; use an HTTPS reverse proxy'))}
