# SMAI AI

A Hebrew, mobile-friendly chat agent with Google sign-in. No OpenAI API, no admin panel, no preset user rules. The model runs in the user's browser using Transformers.js; there is no application credit counter. Device memory, model quality, hosting limits and external-service limits still apply. This is working source code, not an already connected production agent.

## Included

- Chat history separated by Google subject, virtual files with downloads, local memory.
- Open-weight Qwen 0.5B browser inference, streaming replies, lighter 135M fallback. These small models are substantially weaker than ChatGPT and can mishandle multi-step tasks or Hebrew.
- Safari defaults to single-thread WASM; other capable browsers try WebGPU with WASM fallback. Actual Safari/iPhone testing remains outstanding; older devices may not fit the model in memory.
- Optional Playwright cloud browser: live screenshots, navigation, DOM controls, official-site secure credential input, WhatsApp draft preparation. The UI requires approval for consequential external actions. Authentication follows the website's official flow; no bypass of CAPTCHA or verification.
- JavaScript execution on explicitly authorized website origins via SCRIPT_ALLOWED_ORIGINS.
- Optional Python/JavaScript/shell code runner. Output appears in chat. The execution containers do not receive account credentials, host filesystem mounts or general network access.
- Owner-only Home Assistant connector: list lights, turn a chosen light on/off, and read its actual state back. No home connection is active until configured.

## Deploy the chat website from a phone

1. Upload this repository to a GitHub repository you can write to.
2. In Render, create a Blueprint from `render.yaml` (or use another Docker-capable host). Do not choose a paid plan unless you intend to pay.
3. Set `PUBLIC_ORIGIN` to the exact HTTPS origin assigned to the website. Set a random `SESSION_SECRET` of at least 32 characters.
4. Create a Google Identity Services Web OAuth client; register the site's HTTPS origin in Authorized JavaScript origins. Set `GOOGLE_CLIENT_ID` on the host and restart.
5. Open the site and sign in with Google. Without the real OAuth client, the app stays on its login screen; it never fabricates a Google login.

Render's free tier is not unlimited, can sleep and does not provide durable browser profiles. This repository does not provision any cloud resource by itself. A GitHub upload and external deployment have not been completed by the assistant because its current integration lacks branch-write access and external hosting still needs a writable source repository. Render is connected, but no new service has been created.

For development: `npm install`, set values from `.env.example`, then `npm start`. Dependencies are declared but no lockfile has been generated; pin and review resolved versions before production. Run checks with `npm test`.

## Owner identity and cloud browser

Set `BROWSER_OWNER_GOOGLE_SUB` to your verified Google subject, or `BROWSER_OWNER_EMAIL` to your verified Google email. A different registered account cannot use your personal cloud integrations.

Deploy `browser-service` on a suitable Docker host with HTTPS and a persistent `/data` volume. Follow its `.env.example`; configure `ACCESS_TOKEN` and `ALLOWED_ORIGIN`. Configure the website's `BROWSER_SERVICE_URL` and `BROWSER_ACCESS_TOKEN` to match. Server tokens stay on the backend. Playwright needs a host that supports Chromium sandboxing for its non-root user. Docker alone is not a complete hostile-browser security boundary; use a dedicated host and reviewed network policy.

For website JavaScript, set `SCRIPT_ALLOWED_ORIGINS=https://your-test-site.example` on the browser service. This runs in the page, not a host terminal. Use only sites/accounts you are authorized to operate. Any code can modify that page and its account session. A stuck script may require restarting the browser service.

## Code runner

Use a dedicated Linux Docker host or VM, separate from accounts and production infrastructure. Install Node 22+ and Docker, then pre-pull `python:3.12-alpine`, `node:24-alpine` and `alpine:3.22`. Set a random `RUNNER_ACCESS_TOKEN`, then run `node runner-service/server.js` behind an authenticated HTTPS reverse proxy. It binds to loopback on port 4200 by default.

The broker has Docker daemon privileges and must never be installed on a host containing valuable credentials or unrelated production services. It starts short-lived containers as an unprivileged user, with a read-only root, no network, no mounts, dropped capabilities and resource/time/output limits. It is not a universal secure execution platform; use a stronger VM boundary for untrusted workloads. Docker socket access is never passed into code containers.

On the website configure `RUNNER_SERVICE_URL` and `RUNNER_ACCESS_TOKEN`. For tests on your real website use the separately authorized cloud browser and `run_page_code`. General outbound shell access is not implemented. Code files can still be written and downloaded without the runner.

## Home Assistant

Configure the server's `HOME_ASSISTANT_URL` to the HTTPS URL of your own reachable Home Assistant and `HOME_ASSISTANT_TOKEN` to a long-lived access token. Use the same owner identity above. Do not paste tokens into chat. The cloud service must actually be able to reach your home endpoint; this project does not create tunnels or identify your devices automatically.

The connector uses `GET /api/states`, `POST /api/services/light/turn_on` or `turn_off`, and `GET /api/states/light.entity_id`. An accepted command is only reported as confirmed when the returned state matches. For other platforms or devices, add an authenticated connector appropriate to that service.

## Security and storage

Custom prompt rules are empty by default and there is no rules panel in this version. Operational tool schemas, authentication, owner authorization and execution limits remain. No agent can guarantee successful compliance with every instruction or unlimited compute.

Session cookies are signed, HttpOnly and Secure in production. Chat history and virtual files use browser localStorage, which is not encrypted and is not a cloud backup. Clear shared devices after use. Browser-service profiles can hold site logins; protect the host and volume. Password/verification entry does not enter chat or memory, but the service operator and browser session still handle those secrets.

## Primary references

- https://developers.google.com/identity/gsi/web/guides/verify-google-id-token
- https://developers.home-assistant.io/docs/api/rest/
- https://docs.docker.com/engine/containers/run/
- https://playwright.dev/docs/docker
- https://render.com/docs/free


## Server model and durable conversation memory

For a stronger model without phone downloads, host an appropriately licensed instruction model with llama.cpp on a suitable machine. Set MODEL_SERVICE_URL to its authenticated HTTPS origin and MODEL_ACCESS_TOKEN to its secret. This uses llama.cpp's native `/completion` endpoint, not an OpenAI service or OpenAI API key. The prompt template currently uses ChatML and needs a compatible model such as Qwen; other model families require a template change. The connected owner loads the chat immediately without a browser model download. Hosting and hardware still cost resources, and cold starts or slow model inference remain possible. No strong model has actually been deployed or tested here.

Set DATA_DIR to a persistent mounted directory writable by the application user. The server then saves each Google account's conversation state in SQLite and restores it at login on another device. Without that volume only this browser's local history is available. Free Render ephemeral storage is not suitable for durable memory. SQLite state is not encrypted; protect the volume and backups. This implementation provides recent-message context plus saved explicit memory, not perfect recall of every past message; history is capped when prompting the model. Non-streaming server responses currently appear when the completion finishes.

Security checks on owned sites can use the code runner and the authorized browser. Testing requires a specific target and authorization scope. This project is not a promise to break into arbitrary sites, bypass authentication, or complete every security test automatically. Root-level access to accounts and general outbound shell network execution are not implemented.
