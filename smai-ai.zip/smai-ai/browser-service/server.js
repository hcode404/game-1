import http from 'node:http';
import {timingSafeEqual} from 'node:crypto';
import {lookup} from 'node:dns/promises';
import {mkdir} from 'node:fs/promises';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';

export function publicIP(ip){
  if(ip.includes(':'))return /^[23][0-9a-f]{3}:/i.test(ip)&&!/^2001:(db8|0):/i.test(ip);
  const a=ip.split('.').map(Number);
  if(a.length!==4||a.some(n=>!Number.isInteger(n)||n<0||n>255))return false;
  const [x,y]=a;
  return !(x===0||x===10||x===127||x>=224||(x===169&&y===254)||(x===172&&y>=16&&y<=31)||(x===192&&(y===168||y===0))||(x===100&&y>=64&&y<=127)||(x===198&&(y===18||y===19||y===51))||(x===203&&y===0));
}
export async function publicURL(value,resolver=lookup){
  const u=new URL(value);
  if(!['http:','https:'].includes(u.protocol)||u.username||u.password||u.port&&!['80','443'].includes(u.port))throw Error('Only public HTTP/HTTPS pages on standard ports are allowed');
  const host=u.hostname.replace(/^\[|\]$/g,'');
  const addresses=await resolver(host,{all:true});
  if(!addresses.length||addresses.some(a=>!publicIP(a.address)))throw Error('Private or reserved network addresses are blocked');
  return u.href;
}
export function createServer({token,origin,getPage,urlCheck=publicURL,scriptOrigins=[]}){
  if(typeof token!=='string'||token.length<32)throw Error('BROWSER_ACCESS_TOKEN must contain at least 32 characters');
  const allowedOrigin=new URL(origin).origin;
  let active=Promise.resolve();
  const serial=fn=>{const next=active.then(fn,fn);active=next.catch(()=>{});return next;};
  function response(res,status,payload){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(payload));}
  return http.createServer(async(req,res)=>{
    const requestOrigin=req.headers.origin;
    if(requestOrigin&&requestOrigin!==allowedOrigin)return response(res,403,{error:'Origin not allowed'});
    if(requestOrigin){res.setHeader('Access-Control-Allow-Origin',allowedOrigin);res.setHeader('Vary','Origin');}
    if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Methods':'GET, POST, OPTIONS','Access-Control-Allow-Headers':'Authorization, Content-Type','Access-Control-Max-Age':'600'});return res.end();}
    const candidate=req.headers.authorization?.replace(/^Bearer /,'')||'';
    const a=Buffer.from(candidate),b=Buffer.from(token);
    if(a.length!==b.length||!timingSafeEqual(a,b))return response(res,401,{error:'Authentication required'});
    if(req.url==='/health'&&req.method==='GET')return response(res,200,{ok:true});
    try{
      let body={};
      if(req.method==='POST'){
        const chunks=[];let size=0;
        for await(const chunk of req){size+=chunk.length;if(size>100000)throw Error('Request too large');chunks.push(chunk)}
        body=JSON.parse(Buffer.concat(chunks).toString()||'{}');
      }
      await serial(async()=>{
        const page=await getPage();
        if(body.expectedUrl&&body.expectedUrl!==page.url())throw Error('The page changed. Review the live view before acting.');
        if(req.url==='/snapshot'&&req.method==='GET'){
          const snapshot=await page.evaluate(()=>{
            const controls=[...document.querySelectorAll('a,button,input,textarea,select,[role="button"],[contenteditable="true"]')].filter(e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0}).slice(0,160);
            const epoch=Date.now().toString(36);
            window.__personalAgentCounter=window.__personalAgentCounter||0;
            const elements=controls.map(e=>{let id=e.getAttribute('data-personal-agent');if(!id){id=epoch+'-'+window.__personalAgentCounter++;e.setAttribute('data-personal-agent',id);}return {id,tag:e.tagName.toLowerCase(),type:e.getAttribute('type')||'',label:(e.getAttribute('aria-label')||e.getAttribute('placeholder')||e.innerText||'').slice(0,180)}});
            return {title:document.title,text:document.body.innerText.slice(0,6500),elements};
          });
          const image=(await page.screenshot({type:'jpeg',quality:60})).toString('base64');
          return response(res,200,{...snapshot,url:page.url(),width:1280,height:800,image});
        }
        if(req.method!=='POST')return response(res,404,{error:'Not found'});
        switch(req.url){
          case '/navigate':{
            const url=await urlCheck(body.url);
            await page.goto(url,{waitUntil:'domcontentloaded',timeout:30000});
            return response(res,200,{url:page.url(),title:await page.title()});
          }
          case '/click':{
            if(typeof body.id==='string'){
              if(!/^[a-z0-9]+-\d+$/.test(body.id))throw Error('Invalid element ID');
              await page.locator(`[data-personal-agent="${body.id}"]`).click({timeout:5000});
            }else{
              if(!Number.isFinite(body.x)||!Number.isFinite(body.y)||body.x<0||body.x>1280||body.y<0||body.y>800)throw Error('Invalid coordinates');
              await page.mouse.click(body.x,body.y);
            }
            return response(res,200,{clicked:true,url:page.url()});
          }
          case '/fill':{
            if(!/^[a-z0-9]+-\d+$/.test(body.id)||typeof body.text!=='string'||body.text.length>10000)throw Error('Invalid field or text');
            const field=page.locator(`[data-personal-agent="${body.id}"]`);
            const sensitive=await field.evaluate(e=>e.type==='password'||/password|otp|one-time-code/i.test(e.autocomplete||''));
            if(sensitive)throw Error('Use the secure-input panel for passwords and verification codes');
            await field.fill(body.text,{timeout:5000});
            return response(res,200,{filled:true});
          }
          case '/type':{
            if(typeof body.text!=='string'||!body.text.length||body.text.length>2000||/[\r\n]/.test(body.text))throw Error('Invalid text');
            const editable=await page.evaluate(()=>{const e=document.activeElement;return e&&(['INPUT','TEXTAREA'].includes(e.tagName)||e.isContentEditable)});
            if(!editable)throw Error('Click the desired input field in the live view first');
            // Text is never logged, persisted here, returned, or sent to the model.
            await page.keyboard.insertText(body.text);
            return response(res,200,{typed:true});
          }
          case '/scroll':{
            if(!Number.isFinite(body.dy)||Math.abs(body.dy)>2000)throw Error('Invalid scroll distance');
            await page.mouse.wheel(0,body.dy);
            return response(res,200,{scrolled:true});
          }
          case '/evaluate':{
            if(!scriptOrigins.includes(new URL(page.url()).origin))throw Error('Code execution is not enabled for this website origin');
            if(typeof body.code!=='string'||!body.code.trim()||body.code.length>10000)throw Error('Invalid JavaScript');
            let timer;let result;try{result=await Promise.race([page.evaluate(code=>(0,eval)(code),body.code),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Script execution exceeded 10 seconds; restart browser service if the page is stuck')),10000)})]);}finally{clearTimeout(timer)}
            let serialized;
            try{serialized=JSON.stringify(result??null).slice(0,20000)}catch{serialized='Result is not serializable'}
            return response(res,200,{executed:true,url:page.url(),result:serialized});
          }
          case '/whatsapp/prepare':{
            if(typeof body.phone!=='string'||!/^\+?[1-9]\d{7,14}$/.test(body.phone)||typeof body.message!=='string'||body.message.length>5000)throw Error('Supply an exact international phone number and message');
            const phone=body.phone.replace(/^\+/,'');
            await page.goto('https://web.whatsapp.com/send?phone='+encodeURIComponent(phone)+'&text='+encodeURIComponent(body.message),{waitUntil:'domcontentloaded',timeout:30000});
            return response(res,200,{sent:false,phone,message:body.message,instruction:'WhatsApp opened with a requested draft. Complete official device linking if required, verify recipient and draft in the live view, then approve a click on Send. No message has been sent by this action.'});
          }
          default:return response(res,404,{error:'Not found'});
        }
      });
    }catch(error){response(res,400,{error:String(error.message||error).slice(0,350)});}
  });
}

export async function start(){
  const {chromium}=await import('playwright');
  const directory=process.env.BROWSER_DATA_DIR||'/data';
  await mkdir(directory,{recursive:true});
  const context=await chromium.launchPersistentContext(directory,{headless:true,chromiumSandbox:true,viewport:{width:1280,height:800},acceptDownloads:false,locale:'en-US',args:['--disable-dev-shm-usage']});
  // This service is intended for an isolated cloud container, never a privileged host.
  await context.route('**/*',async route=>{try{await publicURL(route.request().url());await route.continue()}catch{await route.abort()}});
  let page=context.pages()[0]||await context.newPage();
  context.on('page',p=>{page=p;});
  const scriptOrigins=(process.env.SCRIPT_ALLOWED_ORIGINS||'').split(',').filter(Boolean).map(v=>new URL(v.trim()).origin);
  const server=createServer({token:process.env.BROWSER_ACCESS_TOKEN,origin:process.env.ALLOWED_ORIGIN,scriptOrigins,getPage:async()=>{if(page.isClosed())page=await context.newPage();return page;}});
  server.listen(Number(process.env.PORT||3000),'0.0.0.0',()=>console.log('Personal browser service is ready'));
  const shutdown=async()=>{server.close();await context.close();process.exit(0)};
  process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);
  return server;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href)start().catch(()=>{console.error('Browser service failed to start; check environment and Chromium installation');process.exit(1)});
