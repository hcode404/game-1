import {mkdir} from 'node:fs/promises';
import {join} from 'node:path';
export async function createStateStore(directory){
 await mkdir(directory,{recursive:true,mode:0o700});
 const {DatabaseSync}=await import('node:sqlite');
 const db=new DatabaseSync(join(directory,'smai.sqlite'));
 db.exec('PRAGMA journal_mode=WAL; CREATE TABLE IF NOT EXISTS state (subject TEXT PRIMARY KEY, data TEXT NOT NULL)');
 const get=db.prepare('SELECT data FROM state WHERE subject=?');
 const set=db.prepare('INSERT INTO state(subject,data) VALUES (?,?) ON CONFLICT(subject) DO UPDATE SET data=excluded.data');
 return {get(subject){const row=get.get(subject);return row?JSON.parse(row.data):null},set(subject,data){set.run(subject,JSON.stringify(data))},close(){db.close()}};
}
